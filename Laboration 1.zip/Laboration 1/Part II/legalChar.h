#pragma once

char legalChar(char value);